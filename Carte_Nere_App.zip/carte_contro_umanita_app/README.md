# Carte Nere

App installabile per giocare con più telefoni.

Contiene:
- 800 carte bianche
- 231 carte nere
- stanze tramite PeerJS
- mani private
- Zar a rotazione
- punteggi automatici
- supporto alle carte con più spazi

## Pubblicazione rapida
1. Carica l'intera cartella su Netlify Drop oppure GitHub Pages.
2. Apri il link HTTPS su tutti i telefoni.
3. Sul primo telefono: "Crea stanza".
4. Sugli altri: inserisci nome e codice.
5. Su iPhone: Condividi > Aggiungi alla schermata Home.

Nota: il collegamento tra telefoni usa PeerJS e richiede internet.
Uso privato e non commerciale.
